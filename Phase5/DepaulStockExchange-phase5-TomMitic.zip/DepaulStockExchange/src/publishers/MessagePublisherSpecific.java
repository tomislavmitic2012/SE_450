package publishers;

import publishers.messages.CancelMessage;
import publishers.messages.FillMessage;
import publishers.messages.MarketMessage;

/**
 * A interface specifying the behaviors a MessagePublisher should implement.
 *
 * @author Tomislav S. Mitic
 */
public interface MessagePublisherSpecific extends MessagePublisherCommon {

  /**
   * Notifies the user of a canceled order.
   *
   * @param cm
   */
  public void publishCancel(CancelMessage cm);

  /**
   * Notifies the user of a fulfilled order.
   *
   * @param fm
   */
  public void publishFill(FillMessage fm);

  /**
   * Notifies all users of a market message.
   *
   * @param mm
   */
  public void publishMarketMessage(MarketMessage mm);
}