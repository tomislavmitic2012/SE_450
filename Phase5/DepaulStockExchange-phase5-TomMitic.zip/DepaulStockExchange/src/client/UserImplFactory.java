package client;

import client.exceptions.UserException;
import client.exceptions.UserImplFactoryException;

/**
 * A factory used to create new users.
 *
 * @author Tomislav S. Mitic
 */
public class UserImplFactory {

  public static UserImpl createUser(String userName)
          throws UserImplFactoryException, UserException {
    if (userName == null || userName.isEmpty()) {
      throw new UserImplFactoryException("Username cannot be null or empty.");
    }
    return new UserImpl(userName);
  }
}