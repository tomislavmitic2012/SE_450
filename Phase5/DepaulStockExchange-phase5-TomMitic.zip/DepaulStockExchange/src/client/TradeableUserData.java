package client;

import client.exceptions.TradeableUserDataException;
import constants.GlobalConstants.BookSide;

/**
 * The TradeableUserData class will hold select data elements related to
 * Tradeables a user has submitted to the system. A list of these object will
 * help the user know what orders they have in the system, and each object
 * contains just enough information to use to generate a cancel if needed.
 *
 * @author Tomislav S. Mitic
 */
public class TradeableUserData {

  /**
   * The name of the user.
   */
  private String userName;

  /**
   * The stock symbol.
   */
  private String product;

  /**
   * The side the order is on.
   */
  private BookSide side;

  private TradeableUserData self = this;

  /**
   * The order ID.
   */
  String id;

  public TradeableUserData(String theName, String theProduct, BookSide theSide,
          String theID) throws TradeableUserDataException {
    setUserName(theName);
    setProduct(theProduct);
    setSide(theSide);
    setID(theID);
  }

  /**
   * Returns the use name for the tradeable that was submitted.
   *
   * @return the user name
   */
  public String getUserName() {
    return userName;
  }

  /**
   * Returns the stock symbol for the tradeable that was submitted.
   *
   * @return the stock symbol
   */
  public String getProduct() {
    return product;
  }

  /**
   * Returns the side for the tradeable that was submitted.
   *
   * @return the side for the tradeable
   */
  public BookSide getSide() {
    return side;
  }

  /**
   * Returns the order ID for the tradeable that was submitted.
   *
   * @return the order id
   */
  public String getID() {
    return id;
  }

  private void setUserName(String user) throws TradeableUserDataException{
    if (user == null || user.isEmpty()) {
      throw new TradeableUserDataException("User name cannot be null or"
              + " empty.");
    }
    userName = user;
  }

  private void setProduct(String prod) throws TradeableUserDataException {
    if (prod == null || prod.isEmpty()) {
      throw new TradeableUserDataException("Stock symbol cannot be null or"
              + " empty.");
    }
    product = prod;
  }

  private void setSide(BookSide theSide) throws TradeableUserDataException {
    if (theSide == null || !(theSide instanceof BookSide)) {
      throw new TradeableUserDataException("The BookSide cannot be null or not"
              + " an instance of BookSide.");
    }
    side = theSide;
  }

  private void setID(String theID) throws TradeableUserDataException {
    if (theID == null || theID.isEmpty()) {
      throw new TradeableUserDataException("Order ID cannot be null or empty.");
    }
    id = theID;
  }

  @Override
  public String toString() {
    return "User " + self.getUserName() + ", " + self.getSide() + " " +
            self.getProduct() + " (" + self.getID() + ")";
  }
}