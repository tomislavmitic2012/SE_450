package client.exceptions;

/**
 * An exception thrown by the UserImplFactory createUser method.
 *
 * @author Tomislav S. Mitic
 */
public class UserImplFactoryException extends Exception {

  public UserImplFactoryException(String message) {
    super(message);
  }
}