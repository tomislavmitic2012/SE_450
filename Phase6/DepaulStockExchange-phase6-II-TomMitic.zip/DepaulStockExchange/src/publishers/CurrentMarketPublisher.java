package publishers;

import client.User;
import publishers.exceptions.MessagePublisherException;
import publishers.messages.MarketDataDTO;

/**
 * This publisher notifies all users of current market conditions in the stock
 * exchange.
 *
 * @author Tomislav S. Mitic
 */
public class CurrentMarketPublisher implements CurrentMarketPublisherSpecific {

  private volatile static CurrentMarketPublisher instance;
  private CurrentMarketPublisherSpecific messagePublisherSubjectImpl;

  public static CurrentMarketPublisher getInstance() {
    if (instance == null) {
      synchronized (CurrentMarketPublisher.class) {
        if (instance == null) {
          instance = MessagePublisherSubjectFactory
                  .createCurrentMarketPublisher();
        }
      }
    }
    return instance;
  }

  protected CurrentMarketPublisher(CurrentMarketPublisherSpecific impl) {
    messagePublisherSubjectImpl = impl;
  }

  @Override
  public synchronized void subscribe(User u, String product)
          throws MessagePublisherException {
    messagePublisherSubjectImpl.subscribe(u, product);
  }

  @Override
  public synchronized void unSubscribe(User u, String product) throws
          MessagePublisherException {
    messagePublisherSubjectImpl.unSubscribe(u, product);
  }

  @Override
  public synchronized void publishCurrentMarket(MarketDataDTO m) {
    messagePublisherSubjectImpl.publishCurrentMarket(m);
  }
}