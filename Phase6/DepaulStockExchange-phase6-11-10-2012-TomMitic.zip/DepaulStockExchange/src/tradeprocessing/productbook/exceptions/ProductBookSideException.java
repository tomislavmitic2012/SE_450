package tradeprocessing.productbook.exceptions;

/**
 *
 * @author tmitic
 */
public class ProductBookSideException extends Exception {

  public ProductBookSideException(String msg) {
    super(msg);
  }
}