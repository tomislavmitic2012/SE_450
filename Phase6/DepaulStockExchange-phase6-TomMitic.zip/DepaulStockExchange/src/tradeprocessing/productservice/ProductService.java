package tradeprocessing.productservice;

import constants.GlobalConstants.BookSide;
import constants.GlobalConstants.MarketState;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map.Entry;
import publishers.MessagePublisher;
import publishers.messages.MarketDataDTO;
import publishers.messages.MarketMessage;
import publishers.messages.exceptions.InvalidMessageException;
import tradeable.Order;
import tradeable.Quote;
import tradeable.TradeableDTO;
import tradeable.exceptions.InvalidVolumeException;
import tradeable.exceptions.TradeableException;
import tradeprocessing.productbook.ProductBook;
import tradeprocessing.productbook.exceptions.DataValidationException;
import tradeprocessing.productbook.exceptions.NoSuchProductException;
import tradeprocessing.productbook.exceptions.OrderNotFoundException;
import tradeprocessing.productbook.exceptions.ProductAlreadyExistsException;
import tradeprocessing.productbook.exceptions.ProductBookException;
import tradeprocessing.productbook.exceptions.ProductBookSideException;
import tradeprocessing.productservice.exceptions.InvalidMarketStateException;
import tradeprocessing.productservice.exceptions.InvalidMarketStateTransitionException;
import tradeprocessing.productservice.exceptions.ProductServiceException;
import tradeprocessing.tradeprocessor.exceptions.InvalidProductBookSideValueException;
import tradeprocessing.tradeprocessor.exceptions.TradeProcessorFactoryException;
import tradeprocessing.tradeprocessor.exceptions.TradeProcessorPriceTimeImplException;

/**
 *  The ProductService is the Façade to the entities that make up the Products
 * (Stocks), and the Product Books (“booked” tradables on the Buy and Sell
 * side). All interaction with the product books and the buy and sell sides of
 * a stock’s book will go through this Façade.
 *
 * @author Tomislav S. Mitic
 */
public class ProductService {
  private volatile static ProductService instance;

  /**
   * As this class must own all the product books, you will need a structure
   * that contains all product books, accessible by the stock symbol name.
   */
  private HashMap<String, ProductBook> allBooks = new HashMap<>();

  /**
   * As this class must maintain a data member that holds the current market
   * state.
   */
  private MarketState state = MarketState.CLOSED;

  /**
   * As this is a Façade, this class should be implemented as a thread-safe
   * singleton.
   *
   * @return the instance of the ProductService
   */
  public static ProductService getInstance() {
    if (instance == null) {
      synchronized (ProductService.class) {
        if (instance == null) {
          instance = new ProductService();
        }
      }
    }
    return instance;
  }

  /**
   * This method will return a List of TradableDTOs containing any orders with
   * remaining quantity for the user and the stock specified.
   *
   * @param userName
   * @param product
   * @return a list of TradeableDTOs
   */
  public synchronized ArrayList<TradeableDTO> getOrdersWithRemainingQty(
          String userName, String product)
          throws ProductBookSideException, ProductBookException,
          ProductServiceException {
    if (userName == null || userName.isEmpty() || product == null ||
            product.isEmpty()) {
      throw new ProductServiceException("Arguments userName and product in"
              + " getOrdersWithRemainginQty cannot be null or empty.");
    }
    return allBooks.get(product).getOrdersWithRemainingQty(userName);
  }

  /**
   * This method will return a List of MarketDataDTO containing the best buy
   * price/volume and sell price/volume for the specified stock product.
   *
   * @param product
   * @return a List of MarketDataDTO
   */
  public synchronized MarketDataDTO getMarketData(String product)
          throws ProductServiceException {
    if (product == null || product.isEmpty()) {
      throw new ProductServiceException("Argument product in getMarketData"
              + " cannot be null or empty.");
    }
    return allBooks.get(product).getMarketData();
  }

  /**
   * This method should simply return the current market state.
   *
   * @return the current market state
   */
  public synchronized MarketState getMarketState() {
    return state;
  }

  /**
   * Returns the Bookdepth for the product passed in.
   *
   * @param product
   * @return a 2-D array of the product book depth
   */
  public synchronized String[][] getBookDepth(String product)
          throws NoSuchProductException, ProductServiceException {
    if (product == null || product.isEmpty()) {
      throw new ProductServiceException("Argument product in getBookDepth"
              + " cannot be null or empty.");
    }
    if (!allBooks.containsKey(product)) {
       throw new NoSuchProductException("The product: " + product +
               "; does not exist in the product book.");
    }
    return allBooks.get(product).getBookDepth();
  }

  /**
   * This method should simply return an Arraylist containing all the keys in
   * the "allBooks" HashMap.
   *
   * @return an ArrayList of all Products
   */
  public synchronized ArrayList<String> getProductList() {
    return new ArrayList<>(allBooks.keySet());
  }

  private synchronized boolean isValidTransition(MarketState ms)
          throws ProductServiceException {
    if (ms == null || !(ms instanceof MarketState)) {
      throw new ProductServiceException("Argument ms in isValidTransition"
              + " cannot be or not an instance of MarketState.");
    }
    ArrayList<MarketState> trans = new ArrayList<>(Arrays.asList(
            MarketState.CLOSED, MarketState.PREOPEN, MarketState.OPEN ));
    int msPass = trans.indexOf(ms);
    int msCurrent = trans.indexOf(state);
    int diff = msPass - msCurrent;
    if (msCurrent == 2 && msPass == 0) { return true; }
    if (msCurrent < msPass && diff == 1) { return true; }
    return false;
  }

  /**
   * This method should update the market state to the new value passed in.
   *
   * @param ms
   */
  public synchronized void setMarketState(MarketState ms)
          throws InvalidMarketStateTransitionException, InvalidMessageException,
          OrderNotFoundException, InvalidVolumeException,
          ProductBookSideException, ProductBookException,
          ProductServiceException, TradeProcessorPriceTimeImplException {
    if (ms == null || !(ms instanceof MarketState)) {
      throw new ProductServiceException("Argument ms in setMarketState"
              + " cannot be or not an instance of MarketState.");
    }
    if (!isValidTransition(ms)) {
      throw new InvalidMarketStateTransitionException("The market state transition: " +
              ms + "; is invalid, current market state is: " + state);
    }
    state = ms;
    MessagePublisher.getInstance().publishMarketMessage(
            new MarketMessage(state));
    if (state.equals(MarketState.OPEN)) {
      for (Entry<String, ProductBook> row : allBooks.entrySet()) {
        row.getValue().openMarket();
      }
    }
    if (state.equals(MarketState.CLOSED)) {
      for (Entry<String, ProductBook> row : allBooks.entrySet()) {
        row.getValue().closeMarket();
      }
    }
  }

  /**
   * This method will create a new stock product that can be used for trading.
   * This will result in the creation of a ProductBook object, and a new entry
   * in the "allBooks" HashMap.
   *
   * @param product
   */
  public synchronized void createProduct(String product)
          throws DataValidationException, ProductAlreadyExistsException,
          ProductBookException, ProductBookSideException,
          InvalidProductBookSideValueException, TradeProcessorFactoryException {
    if (product == null || product.isEmpty()) {
      throw new DataValidationException("Product symbol cannot be "
              + "null or empty.");
    }
    if (allBooks.containsKey(product)) {
      throw new ProductAlreadyExistsException("Product " + product +
              " already exists in the ProductBook.");
    }
    allBooks.put(product, new ProductBook(product));
  }

  /**
   * This method should forward the provided Quote to the appropriate product
   * book.
   *
   * @param q
   */
  public synchronized void submitQuote(Quote q)
          throws InvalidMarketStateException, NoSuchProductException,
          InvalidVolumeException, DataValidationException,
          InvalidMessageException, ProductBookSideException,
          ProductBookException, ProductServiceException,
          TradeProcessorPriceTimeImplException, TradeableException {
    if (q == null) {
      throw new ProductServiceException("Argument q in submitQuote cannot"
              + " be null.");
    }
    if (state.equals(MarketState.CLOSED)) {
      throw new InvalidMarketStateException("Marekt is closed!");
    }
    if (!allBooks.containsKey(q.getProduct())) {
      throw new NoSuchProductException("Product does not exist in any book.");
    }
    allBooks.get(q.getProduct()).addToBook(q);
  }


  /**
   * This method should forward the provided Order to the appropriate product
   * book.
   *
   * @param o
   * @return the string id of the order
   */
  public synchronized String submitOrder(Order o)
          throws InvalidMarketStateException, NoSuchProductException,
          InvalidMessageException, InvalidVolumeException,
          ProductBookSideException, ProductBookException,
          ProductServiceException, TradeProcessorPriceTimeImplException {
    if (o == null) {
      throw new ProductServiceException("Argument o in submitOrder cannot be"
              + " null.");
    }
    if (state.equals(MarketState.CLOSED)) {
      throw new InvalidMarketStateException("Marekt is closed!");
    }
    if (state.equals(MarketState.PREOPEN) && o.getPrice().isMarket()) {
      throw new InvalidMarketStateException("Marekt is pre-open, cannot submit"
              + " MKT orders at this time.");
    }
    if (!allBooks.containsKey(o.getProduct())) {
      throw new NoSuchProductException("Product does not exist in any book.");
    }
    allBooks.get(o.getProduct()).addToBook(o);
    return o.getId();
  }

  /**
   * This method should forward the provided Order Cancel to the appropriate
   * product book.
   *
   * @param product
   * @param side
   * @param orderId
   * @throws InvalidMarketStateException
   * @throws NoSuchProductException
   * @throws InvalidMessageException
   * @throws OrderNotFoundException
   * @throws InvalidVolumeException
   */
  public synchronized void submitOrderCancel(String product, BookSide side,
          String orderId) throws InvalidMarketStateException,
          NoSuchProductException, InvalidMessageException,
          OrderNotFoundException, InvalidVolumeException,
          ProductBookSideException, ProductBookException,
          ProductServiceException {
    if (product == null || product.isEmpty()) {
      throw new ProductServiceException("Argument product in submitOrderCancel "
              + "cannot be null or empty.");
    }
    if (side == null || !(side instanceof BookSide)) {
      throw new ProductServiceException("Argument side in submitOrderCancel"
              + " cannot be null or not an instance of BookSide.");
    }
    if (orderId == null || orderId.isEmpty()) {
      throw new ProductServiceException("Argument orderId in submitOrderCancel"
              + " cannot be null or empty.");
    }
    if (state.equals(MarketState.CLOSED)) {
      throw new InvalidMarketStateException("Marekt is closed!");
    }
    if (!allBooks.containsKey(product)) {
      throw new NoSuchProductException("Product does not exist in any book.");
    }
    allBooks.get(product).cancelOrder(side, orderId);
  }

  /**
   * This method should forward the provided Quote Cancel to the appropriate
   * product book.
   *
   * @param userName
   * @param product
   */
  public synchronized void submitQuoteCancel(String userName, String product)
          throws InvalidMarketStateException, NoSuchProductException,
          InvalidMessageException, ProductBookSideException,
          ProductBookException, ProductServiceException {
    if (userName == null || userName.isEmpty() || product == null ||
            product.isEmpty()) {
      throw new ProductServiceException("Argument userName and product in "
              + "submitQuoteCancel cannot be null or empty.");
    }
    if (state.equals(MarketState.CLOSED)) {
      throw new InvalidMarketStateException("Marekt is closed!");
    }
    if (!allBooks.containsKey(product)) {
      throw new NoSuchProductException("Product does not exist in any book.");
    }
    allBooks.get(product).cancelQuote(userName);
  }
}