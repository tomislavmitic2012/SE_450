package driver;

import client.User;
import constants.GlobalConstants;
import constants.GlobalConstants.BookSide;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import price.Price;
import price.PriceFactory;
import price.exceptions.InvalidPriceOperation;
import publishers.CurrentMarketPublisher;
import publishers.LastSalePublisher;
import publishers.MessagePublisher;
import publishers.TickerPublisher;
import publishers.messages.CancelMessage;
import publishers.messages.FillMessage;
import publishers.messages.MarketDataDTO;
import publishers.messages.MarketMessage;
import tradeable.Order;
import tradeable.Quote;
import tradeable.Tradeable;
import tradeable.TradeableDTO;
import tradeprocessing.productservice.ProductService;

/**
 * This class needs to be in a package called "driver" or it won't compile as
 * is. if you want to put this class in a different package, you need to change
 * the package declaration below to match the desired package name.
 *
 * @author Tomislav S. Mitic
 */
public class Main {

  private static ArrayList<Price> testPriceHolder = new ArrayList<>();
  private static User u1, u2, u3, u4;

  public static void main(String[] args) {
    phase1(false);
    phase2(false);
    phase3(false);
    phase4(true);
  }

  private static void phase1(boolean doIt) {
    if (!doIt) {
      return;
    }
    makeSomeTestPriceObjects();
    verifyTestPriceValues();
    verifyMathematicalOperations();
    verifyBooleanChecks();
    verifyComparisons();
    verifyFlyweight();
        System.out.println("-------------------- End Phase 1"
            + " --------------------");
    System.out.println();
  }

  private static void phase2(boolean doIt) {
    if (!doIt) {
      return;
    }

    // First, create an Order and a Tradable variable to use for testing
    Order order1 = null;
    Tradeable tradable1;

    //1
    try {
      System.out.println("1) Create and print the content of a valid Order:");
      order1 = new Order("USER1", "GE", PriceFactory.makeLimitPrice("$21.59"),
              250, BookSide.BUY);
      System.out.println(order1); // This should execute
    } catch (Exception e) { // Catch anything you throw.
      // This catch block should be skipped if everything is working as it should.
      System.out.println("Creating of a valid Order resulted in an exception!");
      e.printStackTrace();
    }
    System.out.println();
    //////////

    //2
    System.out.println("2) Refer to the Order using a Tradable reference, and display content:");
	tradable1 = order1;
    System.out.println(tradable1);
    System.out.println();
    //////////

    //3
    System.out.println("3) Create and print the content of a TradableDTO (your format may vary, but the data content should be the same):");
    TradeableDTO tDTO = new TradeableDTO(tradable1.getProduct(), tradable1.getPrice(),
                tradable1.getOriginalVolume(), tradable1.getRemainingVolume(),
                tradable1.getCancelledVolume(), tradable1.getUser(),
                tradable1.getSide(), tradable1.isQuote(), tradable1.getId());
    System.out.println(tDTO);
    System.out.println();
    //////////

    //4
    try {
      System.out.println("4) Attempt to create an order using INVALID data "
              + "(Zero volume) - should throw an exception:");
      order1 = new Order("USER1", "GE",
              PriceFactory.makeLimitPrice("$21.59"), 0, BookSide.BUY);
      System.out.println("If this prints then you have accepted invalid "
              + "data in your Order - ERROR!");
    } catch (Exception e) { // Catch anything you throw.
      // This block SHOULD execute.
      System.out.println("Properly handled an invalid volume! Error "
              + "message is: " + e.getMessage());
    }
    System.out.println();
    //////////

    //5
    System.out.println("5) Change the cancelled and remaining volume of the order and display resulting tradable:");
    try {
      tradable1.setRemainingVolume(150);
    } catch (Exception e) {
      System.out.println("Improperly set a remaining volume! Message is: " +
              e.getMessage());
    }
    try {
      tradable1.setCancelledVolume(100);
    } catch (Exception e) {
      System.out.println("Improperly set a cancelled volume! Message is: " +
              e.getMessage());
    }
    System.out.println(tradable1);
    System.out.println();
    //////////

    //6 & 7
    Quote quote1;
    try {
      System.out.println("6) Create and print the content of a valid Quote:");
      quote1 = new Quote("USER2", "GE", PriceFactory.makeLimitPrice("$21.56"),
              100, PriceFactory.makeLimitPrice("$21.62"), 100);
      System.out.println(quote1);
      System.out.println();

      System.out.println("7) Display the individual Quote Sides of the new Quote object:");
      System.out.println("\t" + quote1.getQuoteSide(BookSide.BUY));
      System.out.println("\t" + quote1.getQuoteSide(BookSide.SELL));
    } catch (Exception ex) {
      // This catch block should not execute!
      System.out.println("Creating of a valid Quote resulted in an exception!");
      ex.printStackTrace();
    }
    System.out.println();
    //////////

    //8
    try {
      System.out.println("8) Attempt to create a quote using INVALID data (Zero sell volume) - should throw an exception:");
      quote1 = new Quote("USER2", "GE", PriceFactory.makeLimitPrice("$21.56"), 100, PriceFactory.makeLimitPrice("$21.62"), -50);
      System.out.println("If this prints then you have accepted invalid data in your Quote - ERROR!");
    } catch (Exception e) { // Catch anything you throw.
      System.out.println("Properly handled an invalid volume! Error message is: " + e.getMessage());
    }
    System.out.println("-------------------- End Phase 2"
            + " --------------------");
    System.out.println();
  }

  private static void phase3(boolean doIt) {
    if (!doIt) {
      return;
    }

    performLegacyTests();
    makeTestUsers();
    testCurrentMarketPublisher();
    testTickerPublisher();
    testLastSalePublisher();
    testMessagePublisher();
    System.out.println("-------------------- End Phase 3"
            + " --------------------");
    System.out.println();
  }

  private static void phase4(boolean doIt) {
    if (!doIt) {
      return;
    }

    makeTestUsers();
    doTradingScenarios("GOOG");
    doBadTests("GOOG");
    System.out.println("-------------------- End Phase 4"
            + " --------------------");
    System.out.println();
  }

  private static void doTradingScenarios(String stockSymbol) {

    try {
      System.out.println("1) Check the initial Market State:\n" + ProductService.getInstance().getMarketState() + "\n");

      System.out.print("2) Create a new Stock product in our Trading System: " + stockSymbol);
      ProductService.getInstance().createProduct(stockSymbol);
      System.out.println(", then Query the ProductService for all Stock products:\n"
              + ProductService.getInstance().getProductList() + "\n");

      System.out.println("3) Subscribe 2 test users for CurrentMarket, LastSale, Ticker & Messages");
      CurrentMarketPublisher.getInstance().subscribe(u1, stockSymbol);
      CurrentMarketPublisher.getInstance().subscribe(u2, stockSymbol);
      LastSalePublisher.getInstance().subscribe(u1, stockSymbol);
      LastSalePublisher.getInstance().subscribe(u2, stockSymbol);
      TickerPublisher.getInstance().subscribe(u1, stockSymbol);
      TickerPublisher.getInstance().subscribe(u2, stockSymbol);
      MessagePublisher.getInstance().subscribe(u1, stockSymbol);
      MessagePublisher.getInstance().subscribe(u2, stockSymbol);
      System.out.println("   then change Market State to PREOPEN and verify the Market State...");
      ProductService.getInstance().setMarketState(GlobalConstants.MarketState.PREOPEN);
      System.out.println("Product State: " + ProductService.getInstance().getMarketState() + "\n");

      System.out.println("4) User " + u1.getUserName() + " enters a quote, Current Market updates received by both users: ");
      ProductService.getInstance().submitQuote(
              new Quote(u1.getUserName(), stockSymbol,
              PriceFactory.makeLimitPrice("$641.10"),
              120, PriceFactory.makeLimitPrice("$641.15"), 150));
      System.out.println();

      System.out.println("5) Verify Quote is in Book: ");
      printOutBD(ProductService.getInstance().getBookDepth(stockSymbol));
      System.out.println();

      System.out.println("6) Get MarketDataDTO for " + stockSymbol + " (Your format might vary but the data content should be the same)");
      System.out.println(ProductService.getInstance().getMarketData(stockSymbol));
      System.out.println();

      System.out.println("7) Cancel that Quote, Cancels and Current Market updated received");
      ProductService.getInstance().submitQuoteCancel(u1.getUserName(), stockSymbol);
      System.out.println();

      System.out.println("8) Verify Quote is NOT in Book: ");
      printOutBD(ProductService.getInstance().getBookDepth(stockSymbol));
      System.out.println();

      System.out.println("9) Get MarketDataDTO for " + stockSymbol);
      System.out.println(ProductService.getInstance().getMarketData(stockSymbol));
      System.out.println();

      System.out.println("10) User " + u2.getUserName() + " enters a quote, Current Market received by both users: ");
      ProductService.getInstance().submitQuote(
              new Quote(u2.getUserName(), stockSymbol,
              PriceFactory.makeLimitPrice("$641.10"),
              120, PriceFactory.makeLimitPrice("$641.15"), 150));
      System.out.println();

      System.out.println("11) User " + u1.getUserName() + " enters 5 BUY orders, Current Market updates received (10) by both users for each order: ");
      ProductService.getInstance().submitOrder(
              new Order(u1.getUserName(), stockSymbol,
              PriceFactory.makeLimitPrice("$641.10"), 111,
              GlobalConstants.BookSide.BUY));
      ProductService.getInstance().submitOrder(
              new Order(u1.getUserName(), stockSymbol,
              PriceFactory.makeLimitPrice("$641.11"), 222,
              GlobalConstants.BookSide.BUY));
      ProductService.getInstance().submitOrder(
              new Order(u1.getUserName(), stockSymbol,
              PriceFactory.makeLimitPrice("$641.12"), 333,
              GlobalConstants.BookSide.BUY));
      ProductService.getInstance().submitOrder(
              new Order(u1.getUserName(), stockSymbol,
              PriceFactory.makeLimitPrice("$641.13"), 444,
              GlobalConstants.BookSide.BUY));
      ProductService.getInstance().submitOrder(
              new Order(u1.getUserName(), stockSymbol,
              PriceFactory.makeLimitPrice("$641.14"), 555,
              GlobalConstants.BookSide.BUY));
      System.out.println();

      System.out.println("12) Verify Book: ");
      printOutBD(ProductService.getInstance().getBookDepth(stockSymbol));
      System.out.println();

      System.out.println("13) User " + u2.getUserName() + " enters several 5 Sell orders - no Current Market received - does not improve the market: ");
      ProductService.getInstance().submitOrder(
              new Order(u2.getUserName(), stockSymbol,
              PriceFactory.makeLimitPrice("$641.16"), 111,
              GlobalConstants.BookSide.SELL));
      ProductService.getInstance().submitOrder(
              new Order(u2.getUserName(), stockSymbol,
              PriceFactory.makeLimitPrice("$641.17"), 222,
              GlobalConstants.BookSide.SELL));
      ProductService.getInstance().submitOrder(
              new Order(u2.getUserName(), stockSymbol,
              PriceFactory.makeLimitPrice("$641.18"), 333,
              GlobalConstants.BookSide.SELL));
      ProductService.getInstance().submitOrder(
              new Order(u2.getUserName(), stockSymbol,
              PriceFactory.makeLimitPrice("$641.19"), 444,
              GlobalConstants.BookSide.SELL));
      ProductService.getInstance().submitOrder(
              new Order(u2.getUserName(), stockSymbol,
              PriceFactory.makeLimitPrice("$641.20"), 555,
              GlobalConstants.BookSide.SELL));
      System.out.println();

      System.out.println("14) Verify Book: ");
      printOutBD(ProductService.getInstance().getBookDepth(stockSymbol));
      System.out.println();

      System.out.println("15) User " + u2.getUserName() + " enters a BUY order that is tradable (Current Market received), but won't trade as market is in PREOPEN: ");
      ProductService.getInstance().submitOrder(
              new Order(u2.getUserName(), stockSymbol,
              PriceFactory.makeLimitPrice("$641.15"), 105,
              GlobalConstants.BookSide.BUY));
      System.out.println();

      System.out.println("16) Change Market State to OPEN State...Trade should occur.");
      System.out.println("    Both users should get Market Message, Fill Messages, Current Market, Last Sale & Tickers.");
      ProductService.getInstance().setMarketState(GlobalConstants.MarketState.OPEN);
      System.out.println();

      System.out.println("17) Verify Book after the trade: ");
      printOutBD(ProductService.getInstance().getBookDepth(stockSymbol));
      System.out.println();

      System.out.println("18) User " + u1.getUserName() + " enters a big MKT BUY order to trade with all the SELL side:");
      System.out.println("    Both users should get many Fill Messages, as well as Current Market, Last Sale & Tickers - and a cancel for the unfilled volume");
      ProductService.getInstance().submitOrder(new Order(u1.getUserName(),
              stockSymbol, PriceFactory.makeMarketPrice(), 1750,
              GlobalConstants.BookSide.BUY));
      System.out.println();

      System.out.println("19) Verify Book: ");
      printOutBD(ProductService.getInstance().getBookDepth(stockSymbol));
      System.out.println();

      System.out.println("20) Get Orders with Remaining Quantity: ");
      ArrayList<TradeableDTO> ords = ProductService.getInstance()
              .getOrdersWithRemainingQty(u1.getUserName(), stockSymbol);
      for (TradeableDTO dto : ords) {
        System.out.println(dto);
      }
      System.out.println();

      System.out.println("21) Change Market State to CLOSED State...Both users should get a Market message, many Cancel Messages, and a Current Market Update.");
      ProductService.getInstance().setMarketState(GlobalConstants.MarketState.CLOSED);
      System.out.println();

      System.out.println("22) Verify Book: ");
      printOutBD(ProductService.getInstance().getBookDepth(stockSymbol));
      System.out.println();

      System.out.println("23) Change Market State to PREOPEN then to OPEN. Market messages received");
      ProductService.getInstance().setMarketState(GlobalConstants.MarketState.PREOPEN);
      ProductService.getInstance().setMarketState(GlobalConstants.MarketState.OPEN);
      System.out.println();

      System.out.println("24) User " + u1.getUserName() + " enters a BUY order, Current Market received");
      ProductService.getInstance().submitOrder(new Order(u1.getUserName(),
              stockSymbol, PriceFactory.makeLimitPrice(64130), 369,
              GlobalConstants.BookSide.BUY));
      System.out.println();

      System.out.println("25) User " + u2.getUserName() + " enters a SELL order, users receive Fill Messages, as well as Current Market, Last Sale & Tickers");
      ProductService.getInstance().submitOrder(new Order(u2.getUserName(),
              stockSymbol, PriceFactory.makeLimitPrice(64130), 369,
              GlobalConstants.BookSide.SELL));
      System.out.println();

      System.out.println("26) User " + u1.getUserName() + " enters a MKT BUY order, cancelled as there is no market");
      ProductService.getInstance().submitOrder(new Order(u1.getUserName(),
              stockSymbol, PriceFactory.makeMarketPrice(), 456,
              GlobalConstants.BookSide.BUY));
      System.out.println();

      System.out.println("27) User " + u1.getUserName() + " enters a BUY order, Current Market received");
      ProductService.getInstance().submitOrder(new Order(u1.getUserName(),
              stockSymbol, PriceFactory.makeLimitPrice("641.1"), 151,
              GlobalConstants.BookSide.BUY));
      System.out.println();

      System.out.println("28) User " + u2.getUserName() + " enters a SELL order, users receive Fill Messages, as well as Current Market, Last Sale & Tickers");
      ProductService.getInstance().submitOrder(new Order(u2.getUserName(),
              stockSymbol, PriceFactory.makeLimitPrice(64110), 51,
              GlobalConstants.BookSide.SELL));
      System.out.println();

      System.out.println("29) Change Market State to CLOSED State...Both users should get a Market message, many Cancel Messages, and a Current Market Update.");
      ProductService.getInstance().setMarketState(GlobalConstants.MarketState.CLOSED);
      System.out.println();

      System.out.println("30) Verify Book: ");
      printOutBD(ProductService.getInstance().getBookDepth(stockSymbol));
      System.out.println();
    } catch (Exception ex) {
      Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
    }
  }

  private static void doBadTests(String stockSymbol) {

    try {
      System.out.println("31) Change Market State to PREOPEN then to OPEN. Market messages received");
      ProductService.getInstance().setMarketState(GlobalConstants.MarketState.PREOPEN);
      ProductService.getInstance().setMarketState(GlobalConstants.MarketState.OPEN);
      System.out.println();

      System.out.println("32) User " + u1.getUserName() + " cancels a non-existent order ");
      ProductService.getInstance().submitOrderCancel(stockSymbol, GlobalConstants.BookSide.BUY, "ABC123");
      System.out.println("Did not catch non-existent Stock error!");
    } catch (Exception ex) {
      System.out.println("Properly caught error: " + ex.getMessage());
      System.out.println();
    }

    try {
      System.out.println("33) User " + u1.getUserName() + " cancels a non-existent quote ");
      ProductService.getInstance().submitQuoteCancel(u1.getUserName(), stockSymbol);
      System.out.println("Cancelling a non-existant quote does nothing as expected");
      System.out.println();
    } catch (Exception ex) {
      System.out.println("Caught error that should not have occurred: " + ex.getMessage());
    }

    try {
      System.out.println("34) Try to create a bad product");
      ProductService.getInstance().createProduct(null);
    } catch (Exception ex) {
      System.out.println("Caught error on bad product: " + ex.getMessage());
      System.out.println();
    }

    try {
      System.out.println("35) User " + u1.getUserName() + " enters order on non-existent stock");
      ProductService.getInstance().submitOrder(
              new Order(u1.getUserName(), "X11",
              PriceFactory.makeLimitPrice("$641.10"), 111,
              GlobalConstants.BookSide.BUY));
      System.out.println("Did not catch non-existent Stock error!");
    } catch (Exception ex) {
      System.out.println("Caught error on order for bad class: " + ex.getMessage());
      System.out.println();
    }

    try {
      System.out.println("36) User " + u1.getUserName() + " enters quote on non-existent stock");
      ProductService.getInstance().submitQuote(new Quote(u1.getUserName(),
              "X11", PriceFactory.makeLimitPrice("$641.10"), 120,
              PriceFactory.makeLimitPrice("$641.15"), 150));
      System.out.println("Did not catch non-existent Stock error!");
    } catch (Exception ex) {
      System.out.println("Caught error on quote for bad class: " + ex.getMessage());
      System.out.println();
    }
  }

  private static void makeSomeTestPriceObjects() {
    System.out.println("Creating some Test Price Objects.");
    testPriceHolder.add(PriceFactory.makeLimitPrice("10.50"));
    testPriceHolder.add(PriceFactory.makeLimitPrice("$1400.99"));
    testPriceHolder.add(PriceFactory.makeLimitPrice("$-51.52"));
    testPriceHolder.add(PriceFactory.makeLimitPrice(".49"));
    testPriceHolder.add(PriceFactory.makeLimitPrice("-0.89"));
    testPriceHolder.add(PriceFactory.makeLimitPrice("12"));
    testPriceHolder.add(PriceFactory.makeLimitPrice("90."));
    testPriceHolder.add(PriceFactory.makeLimitPrice("14.5"));
    testPriceHolder.add(PriceFactory.makeMarketPrice());
  }

  private static void verifyTestPriceValues() {
    System.out.println("Verifying the Values in Your Test Price Objects:");
    String format = "%-9s --> %9s : %s%n";
    System.out.format(format, "$10.50", testPriceHolder.get(0), testPriceHolder.get(0).toString().equals("$10.50") ? "CORRECT" : "ERROR");
    System.out.format(format, "$1,400.99", testPriceHolder.get(1), testPriceHolder.get(1).toString().equals("$1,400.99") ? "CORRECT" : "ERROR");
    System.out.format(format, "$-51.52", testPriceHolder.get(2), testPriceHolder.get(2).toString().equals("$-51.52") ? "CORRECT" : "ERROR");
    System.out.format(format, "$0.49", testPriceHolder.get(3), testPriceHolder.get(3).toString().equals("$0.49") ? "CORRECT" : "ERROR");
    System.out.format(format, "$-0.89", testPriceHolder.get(4), testPriceHolder.get(4).toString().equals("$-0.89") ? "CORRECT" : "ERROR");
    System.out.format(format, "$12.00", testPriceHolder.get(5), testPriceHolder.get(5).toString().equals("$12.00") ? "CORRECT" : "ERROR");
    System.out.format(format, "$90.00", testPriceHolder.get(6), testPriceHolder.get(6).toString().equals("$90.00") ? "CORRECT" : "ERROR");
    System.out.format(format, "$14.50", testPriceHolder.get(7), testPriceHolder.get(7).toString().equals("$14.50") ? "CORRECT" : "ERROR");
    System.out.format(format, "MKT", testPriceHolder.get(8), testPriceHolder.get(8).toString().equals("MKT") ? "CORRECT" : "ERROR");
    System.out.println();
  }

  private static void verifyMathematicalOperations() {
    System.out.println("Verifying the Functionality of your Mathematical Operations:");
    String format = "%-9s %c %9s = %9s : %s%n";
    try {
      Price results = testPriceHolder.get(0).add(testPriceHolder.get(1));
      System.out.format(format, testPriceHolder.get(0), '+', testPriceHolder.get(1), results, results.toString().equals("$1,411.49") ? "CORRECT" : "ERROR");
    } catch (InvalidPriceOperation ex) {
      System.out.println("FAILED: " + ex.getMessage());
    }
    try {
      Price results = testPriceHolder.get(1).subtract(testPriceHolder.get(1));
      System.out.format(format, testPriceHolder.get(1), '-', testPriceHolder.get(1), results, results.toString().equals("$0.00") ? "CORRECT" : "ERROR");
    } catch (InvalidPriceOperation ex) {
      System.out.println("FAILED: " + ex.getMessage());
    }
    try {
      Price results = testPriceHolder.get(2).add(testPriceHolder.get(3));
      System.out.format(format, testPriceHolder.get(2), '+', testPriceHolder.get(3), results, results.toString().equals("$-51.03") ? "CORRECT" : "ERROR");
    } catch (InvalidPriceOperation ex) {
      System.out.println("FAILED: " + ex.getMessage());
    }
    try {
      Price results = testPriceHolder.get(3).multiply(4);
      System.out.format(format, testPriceHolder.get(3), '*', 4, results, results.toString().equals("$1.96") ? "CORRECT" : "ERROR");
    } catch (InvalidPriceOperation ex) {
      System.out.println("FAILED: " + ex.getMessage());
    }
    try {
      Price results = testPriceHolder.get(4).subtract(testPriceHolder.get(5));
      System.out.format(format, testPriceHolder.get(4), '-', testPriceHolder.get(5), results, results.toString().equals("$-12.89") ? "CORRECT" : "ERROR");
    } catch (InvalidPriceOperation ex) {
      System.out.println("FAILED: " + ex.getMessage());
    }
    try {
      Price results = testPriceHolder.get(5).add(testPriceHolder.get(6));
      System.out.format(format, testPriceHolder.get(5), '+', testPriceHolder.get(6), results, results.toString().equals("$102.00") ? "CORRECT" : "ERROR");
    } catch (InvalidPriceOperation ex) {
      System.out.println("FAILED: " + ex.getMessage());
    }
    try {
      testPriceHolder.get(8).add(testPriceHolder.get(0));
      System.out.println("ERROR: Adding a LIMIT price to a MARKET Price succeeded: " + testPriceHolder.get(8) + " + " + testPriceHolder.get(0));
    } catch (InvalidPriceOperation ex) {
      System.out.println("CORRECT: " + ex.getMessage() + ": " + testPriceHolder.get(8) + " + " + testPriceHolder.get(0));
    }
    try {
      testPriceHolder.get(8).subtract(testPriceHolder.get(0));
      System.out.println("ERROR: Subtracting a LIMIT price from a MARKET Price succeeded: " + testPriceHolder.get(8) + " - " + testPriceHolder.get(0));
    } catch (InvalidPriceOperation ex) {
      System.out.println("CORRECT: " + ex.getMessage() + ": " + testPriceHolder.get(8) + " - " + testPriceHolder.get(0));
    }
    try {
      testPriceHolder.get(8).multiply(10);
      System.out.println("ERROR: Multiplying a MARKET price succeeded: " + testPriceHolder.get(8) + " + 10");
    } catch (InvalidPriceOperation ex) {
      System.out.println("CORRECT: " + ex.getMessage() + ": " + testPriceHolder.get(8) + " * 10");
    }
        System.out.println();
  }

  private static void verifyBooleanChecks() {
    System.out.println("Verifying the Functionality of your Boolean Checks:");
    System.out.println("Value      | Is Negative | Is Market");
    System.out.println("------------------------------------");
    String format = "%-9s  | %-12s| %-12s%n";
    System.out.format(format, testPriceHolder.get(0), testPriceHolder.get(0).isNegative() ? "ERROR" : "CORRECT", testPriceHolder.get(0).isMarket() ? "ERROR" : "CORRECT");
    System.out.format(format, testPriceHolder.get(1), testPriceHolder.get(1).isNegative() ? "ERROR" : "CORRECT", testPriceHolder.get(1).isMarket() ? "ERROR" : "CORRECT");
    System.out.format(format, testPriceHolder.get(2), testPriceHolder.get(2).isNegative() ? "CORRECT" : "ERROR", testPriceHolder.get(2).isMarket() ? "ERROR" : "CORRECT");
    System.out.format(format, testPriceHolder.get(3), testPriceHolder.get(3).isNegative() ? "ERROR" : "CORRECT", testPriceHolder.get(3).isMarket() ? "ERROR" : "CORRECT");
    System.out.format(format, testPriceHolder.get(4), testPriceHolder.get(4).isNegative() ? "CORRECT" : "ERROR", testPriceHolder.get(4).isMarket() ? "ERROR" : "CORRECT");
    System.out.format(format, testPriceHolder.get(5), testPriceHolder.get(5).isNegative() ? "ERROR" : "CORRECT", testPriceHolder.get(5).isMarket() ? "ERROR" : "CORRECT");
    System.out.format(format, testPriceHolder.get(6), testPriceHolder.get(6).isNegative() ? "ERROR" : "CORRECT", testPriceHolder.get(6).isMarket() ? "ERROR" : "CORRECT");
    System.out.format(format, testPriceHolder.get(7), testPriceHolder.get(7).isNegative() ? "ERROR" : "CORRECT", testPriceHolder.get(7).isMarket() ? "ERROR" : "CORRECT");
    System.out.format(format, testPriceHolder.get(8), testPriceHolder.get(8).isNegative() ? "ERROR" : "CORRECT", testPriceHolder.get(8).isMarket() ? "CORRECT" : "ERROR");
    System.out.println();
  }

  private static void verifyComparisons() {
    System.out.println("Verifying the Functionality of your Boolean Comparisons:");
    Price testPrice = testPriceHolder.get(7);

    String format = "%-10s | %-15s | %-12s | %-12s | %-9s%n";
    System.out.println("Comparison\nto " + testPrice + "  | greaterOrEqual  | greaterThan  | lessOrEqual  | lessThan");
    System.out.println("---------------------------------------------------------------------");
    System.out.format(format, testPriceHolder.get(0),
            testPriceHolder.get(0).greaterOrEqual(testPrice) ? "ERROR" : "CORRECT", testPriceHolder.get(0).greaterThan(testPrice) ? "ERROR" : "CORRECT",
            testPriceHolder.get(0).lessOrEqual(testPrice) ? "CORRECT" : "ERROR", testPriceHolder.get(0).lessThan(testPrice) ? "CORRECT" : "ERROR");
    System.out.format(format, testPriceHolder.get(1),
            testPriceHolder.get(1).greaterOrEqual(testPrice) ? "CORRECT" : "ERROR", testPriceHolder.get(1).greaterThan(testPrice) ? "CORRECT" : "ERROR",
            testPriceHolder.get(1).lessOrEqual(testPrice) ? "ERROR" : "CORRECT", testPriceHolder.get(1).lessThan(testPrice) ? "ERROR" : "CORRECT");
    System.out.format(format, testPriceHolder.get(2),
            testPriceHolder.get(2).greaterOrEqual(testPrice) ? "ERROR" : "CORRECT", testPriceHolder.get(2).greaterThan(testPrice) ? "ERROR" : "CORRECT",
            testPriceHolder.get(2).lessOrEqual(testPrice) ? "CORRECT" : "ERROR", testPriceHolder.get(2).lessThan(testPrice) ? "CORRECT" : "ERROR");
    System.out.format(format, testPriceHolder.get(3),
            testPriceHolder.get(3).greaterOrEqual(testPrice) ? "ERROR" : "CORRECT", testPriceHolder.get(3).greaterThan(testPrice) ? "ERROR" : "CORRECT",
            testPriceHolder.get(3).lessOrEqual(testPrice) ? "CORRECT" : "ERROR", testPriceHolder.get(3).lessThan(testPrice) ? "CORRECT" : "ERROR");
    System.out.format(format, testPriceHolder.get(4),
            testPriceHolder.get(4).greaterOrEqual(testPrice) ? "ERROR" : "CORRECT", testPriceHolder.get(4).greaterThan(testPrice) ? "ERROR" : "CORRECT",
            testPriceHolder.get(4).lessOrEqual(testPrice) ? "CORRECT" : "ERROR", testPriceHolder.get(4).lessThan(testPrice) ? "CORRECT" : "ERROR");
    System.out.format(format, testPriceHolder.get(5),
            testPriceHolder.get(5).greaterOrEqual(testPrice) ? "ERROR" : "CORRECT", testPriceHolder.get(5).greaterThan(testPrice) ? "ERROR" : "CORRECT",
            testPriceHolder.get(5).lessOrEqual(testPrice) ? "CORRECT" : "ERROR", testPriceHolder.get(5).lessThan(testPrice) ? "CORRECT" : "ERROR");
    System.out.format(format, testPriceHolder.get(6),
            testPriceHolder.get(6).greaterOrEqual(testPrice) ? "CORRECT" : "ERROR", testPriceHolder.get(6).greaterThan(testPrice) ? "CORRECT" : "ERROR",
            testPriceHolder.get(6).lessOrEqual(testPrice) ? "ERROR" : "CORRECT", testPriceHolder.get(6).lessThan(testPrice) ? "ERROR" : "CORRECT");
    System.out.format(format, testPriceHolder.get(7),
            testPriceHolder.get(7).greaterOrEqual(testPrice) ? "CORRECT" : "ERROR", testPriceHolder.get(7).greaterThan(testPrice) ? "ERROR" : "CORRECT",
            testPriceHolder.get(7).lessOrEqual(testPrice) ? "CORRECT" : "ERROR", testPriceHolder.get(7).lessThan(testPrice) ? "ERROR" : "CORRECT");
    System.out.format(format, testPriceHolder.get(8),
            testPriceHolder.get(8).greaterOrEqual(testPrice) ? "ERROR" : "CORRECT", testPriceHolder.get(8).greaterThan(testPrice) ? "ERROR" : "CORRECT",
            testPriceHolder.get(8).lessOrEqual(testPrice) ? "ERROR" : "CORRECT", testPriceHolder.get(8).lessThan(testPrice) ? "ERROR" : "CORRECT");
    System.out.println();
  }

  private static void verifyFlyweight() {
    System.out.println("Verifying your Flyweight Implementation:");
    String format = "Price %-9s is same object as new %9s: %s%n";
    Price p1 = PriceFactory.makeLimitPrice("10.50");
    System.out.format(format, testPriceHolder.get(0), p1, testPriceHolder.get(0) == p1 ? "CORRECT" : "ERROR");
    System.out.format(format, testPriceHolder.get(1), p1, testPriceHolder.get(1) == p1 ? "ERROR" : "CORRECT");

    p1 = PriceFactory.makeMarketPrice();
    System.out.format(format, testPriceHolder.get(8), p1, testPriceHolder.get(8) == p1 ? "CORRECT" : "ERROR");
    System.out.format(format, testPriceHolder.get(1), p1, testPriceHolder.get(1) == p1 ? "ERROR" : "CORRECT");
  }

  private static void performLegacyTests() {
    Price p1 = PriceFactory.makeLimitPrice("15.00");
    Price p2 = PriceFactory.makeLimitPrice("$15.00");
    Price p3 = PriceFactory.makeLimitPrice("15");

    // Insure Flyweight functionality
    System.out.println("1) The Strings '15.00 and '$15.00' and '15' should all result in the same Price object holding a long of 1500");
    boolean r = p1 == p2;
    System.out.println("\tIs 'p1'(15.00) the same Price object as 'p2' ($15.00): " + r + " (" + (r ? "CORRECT" : "ERROR") + ")");
    r = p1 == p3;
    System.out.println("\tIs 'p1'(15.00) the same Price object as 'p3' (15): " + r + " (" + (r ? "CORRECT" : "ERROR") + ")");
    r = p2 == p3;
    System.out.println("\tIs 'p2'($15.00) the same Price object as 'p3' (15): " + r + " (" + (r ? "CORRECT" : "ERROR") + ")");
    r = p1 == p1;
    System.out.println("\tIs 'p1'(15.00) the same Price object as 'p1' (15.00): " + r + " (" + (r ? "CORRECT" : "ERROR") + ")");
    r = p2 == p2;
    System.out.println("\tIs 'p2'($15.00) the same Price object as 'p2' ($15.00): " + r + " (" + (r ? "CORRECT" : "ERROR") + ")");
    r = p3 == p3;
    System.out.println("\tIs 'p3'(15) the same Price object as 'p3' (15): " + r + " (" + (r ? "CORRECT" : "ERROR") + ")");

    System.out.println("Done with legacy tests\n");
  }

  private static void makeTestUsers() {
    u1 = new UserImpl("REX");
    u2 = new UserImpl("ANN");
    u3 = new UserImpl("OWL");
    u4 = new UserImpl("BEN");
  }

  private static void testCurrentMarketPublisher() {
    try {
      CurrentMarketPublisher.getInstance().subscribe(u1, "SBUX");
      CurrentMarketPublisher.getInstance().subscribe(u2, "IBM");
      CurrentMarketPublisher.getInstance().subscribe(u3, "AAPL");

      System.out.println("2) Publish Current Market for SBUX. Only user REX is subscribed, only REX gets a message:");
      MarketDataDTO mdo = new MarketDataDTO("SBUX", PriceFactory.makeLimitPrice("51.00"), 120, PriceFactory.makeLimitPrice("51.06"), 75);
      CurrentMarketPublisher.getInstance().publishCurrentMarket(mdo);
      System.out.println();

      System.out.println("3) Publish Current Market for IBM. Only user ANN is subscribed, only ANN gets a message:");
      MarketDataDTO mdo2 = new MarketDataDTO("IBM", PriceFactory.makeLimitPrice("205.85"), 300, PriceFactory.makeLimitPrice("205.98"), 220);
      CurrentMarketPublisher.getInstance().publishCurrentMarket(mdo2);
      System.out.println();

      System.out.println("4) Publish Current Market for GE. No user is subscribed, no user gets a message:");
      MarketDataDTO mdo3 = new MarketDataDTO("GE", PriceFactory.makeLimitPrice("22.70"), 40, PriceFactory.makeLimitPrice("22.78"), 110);
      CurrentMarketPublisher.getInstance().publishCurrentMarket(mdo3);
      System.out.println();

      CurrentMarketPublisher.getInstance().subscribe(u2, "SBUX");
      CurrentMarketPublisher.getInstance().subscribe(u3, "SBUX");
      CurrentMarketPublisher.getInstance().subscribe(u4, "SBUX");

      System.out.println("5) Publish Current Market for SBUX. Now all 4 users are subscribed so REX, ANN, OWL & BEN get a message");
      MarketDataDTO mdo4 = new MarketDataDTO("SBUX", PriceFactory.makeLimitPrice("51.04"), 225, PriceFactory.makeLimitPrice("51.12"), 117);
      CurrentMarketPublisher.getInstance().publishCurrentMarket(mdo4);
      System.out.println();

      CurrentMarketPublisher.getInstance().unSubscribe(u1, "SBUX");
      CurrentMarketPublisher.getInstance().unSubscribe(u2, "SBUX");
      CurrentMarketPublisher.getInstance().unSubscribe(u3, "SBUX");
      CurrentMarketPublisher.getInstance().unSubscribe(u4, "SBUX");

      System.out.println("6) Publish Current Market for SBUX. Now all 4 users are unsubscribed so no one get a message");
      MarketDataDTO mdo5 = new MarketDataDTO("SBUX", PriceFactory.makeLimitPrice("51.10"), 110, PriceFactory.makeLimitPrice("51.13"), 120);
      CurrentMarketPublisher.getInstance().publishCurrentMarket(mdo5);
      System.out.println("Done with Current Market tests\n");

    } catch (Exception ex) {
      Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
    }
  }

  private static void testTickerPublisher() {
    try {
      TickerPublisher.getInstance().subscribe(u1, "SBUX");
      TickerPublisher.getInstance().subscribe(u2, "IBM");

      System.out.println("7) Publish Ticker for SBUX. Only user REX is subscribed, only REX gets a message:");
      TickerPublisher.getInstance().publishTicker("SBUX", PriceFactory.makeLimitPrice("52.00"));
      System.out.println();

      System.out.println("8) Publish Ticker for IBM. Only user ANN is subscribed, only ANN gets a message:");
      TickerPublisher.getInstance().publishTicker("IBM", PriceFactory.makeLimitPrice("204.85"));
      System.out.println();

      System.out.println("9) Publish Ticker for GE. No user is subscribed, no user gets a message:");
      TickerPublisher.getInstance().publishTicker("GE", PriceFactory.makeLimitPrice("22.70"));
      System.out.println();

      TickerPublisher.getInstance().subscribe(u2, "SBUX");
      TickerPublisher.getInstance().subscribe(u3, "SBUX");
      TickerPublisher.getInstance().subscribe(u4, "SBUX");

      System.out.println("10) Publish Last Sale for SBUX. Now all 4 users are subscribed so REX, ANN, OWL & BEN get a message");
      TickerPublisher.getInstance().publishTicker("SBUX", PriceFactory.makeLimitPrice("52.10"));
      System.out.println();

      TickerPublisher.getInstance().unSubscribe(u1, "SBUX");
      TickerPublisher.getInstance().unSubscribe(u2, "SBUX");
      TickerPublisher.getInstance().unSubscribe(u3, "SBUX");
      TickerPublisher.getInstance().unSubscribe(u4, "SBUX");

      System.out.println("11) Publish Last Sale for SBUX. Now all 4 users are unsubscribed so no one get a message");
      TickerPublisher.getInstance().publishTicker("SBUX", PriceFactory.makeLimitPrice("52.12"));
      System.out.println("Done with Ticker tests\n");
    } catch (Exception ex) {
      Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
    }
  }

  private static void testLastSalePublisher() {
    try {
      LastSalePublisher.getInstance().subscribe(u1, "SBUX");
      LastSalePublisher.getInstance().subscribe(u2, "IBM");

      System.out.println("12) Publish Last Sale for SBUX. Only user REX is subscribed, only REX gets a message:");
      LastSalePublisher.getInstance().publishLastSale("SBUX", PriceFactory.makeLimitPrice("51.00"), 120);
      System.out.println();

      System.out.println("13) Publish Last Sale for IBM. Only user ANN is subscribed, only ANN gets a message:");
      LastSalePublisher.getInstance().publishLastSale("IBM", PriceFactory.makeLimitPrice("205.85"), 300);
      System.out.println();

      System.out.println("14) Publish Last Sale for GE. No user is subscribed, no user gets a message:");
      LastSalePublisher.getInstance().publishLastSale("GE", PriceFactory.makeLimitPrice("22.70"), 40);
      System.out.println();

      LastSalePublisher.getInstance().subscribe(u2, "SBUX");
      LastSalePublisher.getInstance().subscribe(u3, "SBUX");
      LastSalePublisher.getInstance().subscribe(u4, "SBUX");

      System.out.println("15) Publish Last Sale for SBUX. Now all 4 users are subscribed so REX, ANN, OWL & BEN get a message");
      LastSalePublisher.getInstance().publishLastSale("SBUX", PriceFactory.makeLimitPrice("51.00"), 120);
      System.out.println();

      LastSalePublisher.getInstance().unSubscribe(u1, "SBUX");
      LastSalePublisher.getInstance().unSubscribe(u2, "SBUX");
      LastSalePublisher.getInstance().unSubscribe(u3, "SBUX");
      LastSalePublisher.getInstance().unSubscribe(u4, "SBUX");

      System.out.println("16) Publish Last Sale for SBUX. Now all 4 users are unsubscribed so no one get a message");
      LastSalePublisher.getInstance().publishLastSale("SBUX", PriceFactory.makeLimitPrice("51.00"), 120);
      System.out.println("Done with Last Sale tests\n");

    } catch (Exception ex) {
      Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
    }
  }

  private static void testMessagePublisher() {
    try {
      MessagePublisher.getInstance().subscribe(u1, "SBUX");
      MessagePublisher.getInstance().subscribe(u2, "SBUX");

      System.out.println("17) Send a CancelMessage to REX. REX is subscribed for SBUX messages so REX gets the message.");
      CancelMessage cm = new CancelMessage("REX", "SBUX", PriceFactory.makeLimitPrice("52.00"), 140, "Cancelled By User", BookSide.BUY, "ABC123XYZ");
      MessagePublisher.getInstance().publishCancel(cm);
      System.out.println();

      System.out.println("18) Send a CancelMessage to REX. REX is NOT subscribed for IBM messages so REX does not get the message.");
      CancelMessage cm2 = new CancelMessage("REX", "IBM", PriceFactory.makeLimitPrice("52.00"), 140, "Cancelled By User", BookSide.BUY, "ABC123XYZ");
      MessagePublisher.getInstance().publishCancel(cm2);
      System.out.println();

      System.out.println("19) Send a CancelMessage to ANN. ANN is subscribed for SBUX messages so ANN gets the message.");
      CancelMessage cm3 = new CancelMessage("ANN", "SBUX", PriceFactory.makeLimitPrice("52.00"), 140, "Cancelled By User", BookSide.BUY, "ABC123XYZ");
      MessagePublisher.getInstance().publishCancel(cm3);
      System.out.println();

      System.out.println("20) Send a CancelMessage to ANN. ANN is NOT subscribed for IBM messages so ANN does not get the message.");
      CancelMessage cm4 = new CancelMessage("ANN", "IBM", PriceFactory.makeLimitPrice("52.00"), 140, "Cancelled By User", BookSide.BUY, "ABC123XYZ");
      MessagePublisher.getInstance().publishCancel(cm4);
      System.out.println();

      System.out.println("21) Send a FillMessage to REX. REX is subscribed for SBUX messages so REX gets the message.");
      FillMessage fm = new FillMessage("REX", "SBUX", PriceFactory.makeLimitPrice("52.00"), 140, "Filled By User", BookSide.BUY, "ABC123XYZ");
      MessagePublisher.getInstance().publishFill(fm);
      System.out.println();

      System.out.println("22) Send a FillMessage to REX. REX is NOT subscribed for IBM messages so REX does not get the message.");
      FillMessage fm2 = new FillMessage("REX", "IBM", PriceFactory.makeLimitPrice("52.00"), 140, "Filled By User", BookSide.BUY, "ABC123XYZ");
      MessagePublisher.getInstance().publishFill(fm2);
      System.out.println();

      System.out.println("23) Send a FillMessage to ANN. ANN is subscribed for SBUX messages so ANN gets the message.");
      FillMessage fm3 = new FillMessage("ANN", "SBUX", PriceFactory.makeLimitPrice("52.00"), 140, "Filled By User", BookSide.BUY, "ABC123XYZ");
      MessagePublisher.getInstance().publishFill(fm3);
      System.out.println();

      System.out.println("24) Send a FillMessage to ANN. ANN is NOT subscribed for IBM messages so ANN does not get the message.");
      FillMessage fm4 = new FillMessage("ANN", "IBM", PriceFactory.makeLimitPrice("52.00"), 140, "Filled By User", BookSide.BUY, "ABC123XYZ");
      MessagePublisher.getInstance().publishFill(fm4);
      System.out.println();

      MessagePublisher.getInstance().unSubscribe(u2, "SBUX");
      System.out.println("25) Send a MarketMessage. REX is the only MessagePublisher subscriber so only REX gets the message.");
      MarketMessage mm = new MarketMessage(GlobalConstants.MarketState.PREOPEN);
      MessagePublisher.getInstance().publishMarketMessage(mm);
      System.out.println();

      MessagePublisher.getInstance().subscribe(u2, "SBUX");
      System.out.println("26) Send a MarketMessage. REX and ANN are MessagePublisher subscribers so REX & Ann get the message.");
      MarketMessage mm2 = new MarketMessage(GlobalConstants.MarketState.OPEN);
      MessagePublisher.getInstance().publishMarketMessage(mm2);
      System.out.println();

      MessagePublisher.getInstance().unSubscribe(u1, "SBUX");
      MessagePublisher.getInstance().unSubscribe(u2, "SBUX");
      System.out.println("27) Send a MarketMessage. No users are MessagePublisher subscribers so No users get the message.");
      MarketMessage mm3 = new MarketMessage(GlobalConstants.MarketState.CLOSED);
      MessagePublisher.getInstance().publishMarketMessage(mm3);
      System.out.println("Done with Message tests\n");
    } catch (Exception ex) {
      Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
    }
  }

  private static void printOutBD(String[][] bd) {
    String[] buy = bd[0];
    String[] sell = bd[1];
    System.out.println("Buy Side:");
    for (String s : buy) {
      System.out.println("\t" + s);
    }
    System.out.println("Sell Side:");
    for (String s : sell) {
      System.out.println("\t" + s);
     }
    }

  static class UserImpl implements User {

    private String uname;

    public UserImpl(String u) {
      uname = u;
    }

    @Override
    public String getUserName() {
      return uname;
    }

    @Override
    public void acceptLastSale(String product, Price p, int v) {
      System.out.println("User " + getUserName() + " Received Last Sale for " + product + " " + v + "@" + p);
    }

    @Override
    public void acceptMessage(FillMessage fm) {
      System.out.println("User " + getUserName() + " Received Fill Message: " + fm);
    }

    @Override
    public void acceptMessage(CancelMessage cm) {
      System.out.println("User " + getUserName() + " Received Cancel Message: " + cm);
    }

    @Override
    public void acceptMarketMessage(String message) {
      System.out.println("User " + getUserName() + " Received Market Message: " + message);
    }

    @Override
    public void acceptTicker(String product, Price p, char direction) {
      System.out.println("User " + getUserName() + " Received Ticker for " + product + " " + p + " " + direction);
    }

    @Override
    public void acceptCurrentMarket(String product, Price bp, int bv, Price sp, int sv) {
      System.out.println("User " + getUserName() + " Received Current Market for " + product + " " + bv + "@" + bp + " - " + sv + "@" + sp);
    }
  }
}