package publishers.messages;

import constants.GlobalConstants.BookSide;
import price.Price;

/**
 * The interface which defines the behavior for Cancel and Fill Messages.
 *
 * @author Tomislav S. Mitic
 */
public interface GeneralMarketMessage {

  /**
   * Returns the user of the order/quote side associated with this
   * cancel/fill message.
   *
   * @return user
   */
  public String getUser();

  /**
   * Returns the product of the order/quote side associated with this
   * cancel/fill message.
   *
   * @return product
   */
  public String getProduct();

  /**
   * Returns the price of the order/quote side associated with this
   * cancel/fill message.
   *
   * @return price
   */
  public Price getPrice();

  /**
   * Returns the volume of the order/quote side associated with this
   * cancel/fill message.
   *
   * @return volume
   */
  public int getVolume();

  /**
   * Returns the details associated with this cancel/fill message.
   *
   * @return details
   */
  public String getDetails();

  /**
   * Returns the side of the order/quote side associated with this
   * cancel/fill message.
   *
   * @return side
   */
  public BookSide getSide();
}