package publishers.messages;

import constants.GlobalConstants.BookSide;
import price.Price;
import publishers.messages.exceptions.InvalidMessageException;

/**
 * The implementation for Cancel and Fill Messages.
 *
 * @author Tomislav S. Mitic
 */
class GeneralMarketMessageImpl implements GeneralMarketMessage {

  /**
   * The String username of the user whose order or quote-side is being
   * cancelled/filled. Cannot be null or empty.
   */
  private String user;

  /**
   * The string stock symbol that the cancelled/filled order or quote-side was
   * submitted for; example ("IBM", "GE", etc.). Cannot be null or empty.
   */
  private String product;

  /**
   * The price specified in the cancelled/filled order or quote-side.
   * Cannot be null.
   */
  private Price price;

  /**
   * The quantity of the order or quote-side that was cancelled/filled.
   * Cannot be negative.
   */
  private int volume;

  /**
   * A text description of the cancellation/fulfillment. Cannot be null.
   */
  private String details;

  /**
   * The side (BUY/SELL) of the cancelled/filled order or quote-side.
   * Must be a valid side.
   */
  private BookSide side;

  /**
   * The String identifier of the cancelled/filled order or quote-side.
   * Cannot be null.
   */
  public String id;

  /**
   * Creates a general implementation that will be delegated to be cancel and
   * fill messages.
   *
   * @param user
   * @param product
   * @param price
   * @param volume
   * @param details
   * @param side
   * @param id
   * @throws InvalidMessageException
   */
  public GeneralMarketMessageImpl(String user, String product, Price price,
          int volume, String details, BookSide side, String id)
            throws InvalidMessageException {
    setUser(user);
    setProduct(product);
    setPrice(price);
    setVolume(volume);
    setDetails(details);
    setSide(side);
    setId(id);
  }

  @Override
  public final String getUser() {
    return user;
  }

  @Override
  public final String getProduct() {
    return product;
  }

  @Override
  public final Price getPrice() {
    return price;
  }

  @Override
  public final int getVolume() {
    return volume;
  }

  @Override
  public final String getDetails() {
    return details;
  }

  @Override
  public final BookSide getSide() {
    return side;
  }

  private void setUser(String user) throws InvalidMessageException {
    if (user == null || user.isEmpty()) {
      throw new InvalidMessageException("User cannot be null or empty.");
    }
    this.user = user;
  }

  private void setProduct(String product) throws InvalidMessageException {
    if (product == null || product.isEmpty()) {
      throw new InvalidMessageException("Product cannot be null or empty.");
    }
    this.product = product;
  }

  private void setPrice(Price price) throws InvalidMessageException {
    if (price == null) {
      throw new InvalidMessageException("Price cannot be null");
    }
    this.price = price;
  }

  private void setVolume(int volume) throws InvalidMessageException {
    if (volume < 0) {
      throw new InvalidMessageException("Volume cannot be negative.");
    }
    this.volume = volume;
  }

  private void setDetails(String details) throws InvalidMessageException {
    if (details == null || details.isEmpty()) {
      throw new InvalidMessageException("Details cannot be null or empty");
    }
    this.details = details;
  }

  private void setSide(BookSide side) throws InvalidMessageException {
    if (!(side instanceof BookSide)) {
      throw new InvalidMessageException("Side must be a valid Book Side");
    }
    this.side = side;
  }

  private void setId(String id) throws InvalidMessageException {
    if (id == null || id.isEmpty()) {
      throw new InvalidMessageException("ID cannot be null or empty.");
    }
    this.id = id;
  }

  @Override
  public String toString() {
    return "User: " + user + ", Product: " + product + ", Price: " + price +
            ", Volume: " + volume + ", Details: " + details + ", Side: " +
            side + ", ID: " + id;
  }
}