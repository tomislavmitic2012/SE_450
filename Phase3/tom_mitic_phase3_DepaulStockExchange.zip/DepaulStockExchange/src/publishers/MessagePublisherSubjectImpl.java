package publishers;

import client.User;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import price.Price;
import publishers.exceptions.MessagePublisherException;
import publishers.messages.CancelMessage;
import publishers.messages.FillMessage;
import publishers.messages.MarketDataDTO;
import publishers.messages.MarketMessage;

/**
 * The implementation of the MessagePublisher interface that publishers will use
 * to subscribe and un-subscribe users from.
 *
 * @author Tomislav S. Mitic
 */
class MessagePublisherSubjectImpl implements MessagePublisherSubject {

  /**
   * A hash map of of keys representing stock symbols and a HashSet of users
   * subscribed to those symbols for stock market updates.
   */
  private Map<String, Set<User>> subscribers;

  /**
   * A hash map of the most recent ticker price for a stock symbol.
   */
  private Map<String, Price> stockTickerValue;

  protected MessagePublisherSubjectImpl() {
    subscribers = new HashMap<>();
    stockTickerValue = new HashMap<>();
  }

  @Override
  public synchronized final void subscribe(User u, String product)
          throws MessagePublisherException {
    // Create the HashSet of users if the Product does not exist in the
    // subscribers hash map
    createUserSetForProduct(product);
    Set<User> set = subscribers.get(product);
    if (set.contains(u)) {
      throw new MessagePublisherException("The users is already subscribed to "
              + "receive updates for this stock symbol: " + product);
    }
    set.add(u);
  }

  @Override
  public synchronized final void unSubscribe(User u, String product)
          throws MessagePublisherException {
    Set<User> set = subscribers.get(product);
    if (set == null) {
      throw new MessagePublisherException("No one is registered for this "
              + "stock symbol: " + product);
    }
    if (!set.contains(u)) {
      throw new MessagePublisherException("The user is not subscribed to "
              + "receive updates for this stock symbol: " + product);
    }
    set.remove(u);
  }

  private synchronized void createUserSetForProduct(String product) {
    if (!subscribers.containsKey(product)) {
      subscribers.put(product, new HashSet<User>());
    }
  }

  @Override
  public synchronized void publishCurrentMarket(MarketDataDTO m) {
    if (!subscribers.containsKey(m.product)) { return; }
    Set<User> users = subscribers.get(m.product);
    for (User u : users) {
      u.acceptCurrentMarket(m.product, m.buyPrice, m.buyVolume, m.sellPrice,
              m.sellVolume);
    }
  }

  @Override
  public synchronized void publishLastSale(String product, Price p, int v) {
    if (!subscribers.containsKey(product)) { return; }
    Set<User> users = subscribers.get(product);
    for (User u : users) {
      u.acceptLastSale(product, p, v);
    }
    TickerPublisher.getInstance().publishTicker(product, p);
  }

  @Override
  public synchronized void publishTicker(String product, Price p) {
    if (!subscribers.containsKey(product)) { return; }
    char direction = ' ';
    Price val = stockTickerValue.get(product);
    if (val != null) {
      if (p.equals(val)) {
        direction = '=';
      } else if (p.greaterThan(val)) {
        direction = '\u2191';
      } else if (p.lessThan(val)) {
        direction = '\u2193';
      }
    }
    stockTickerValue.put(product, p);
    Set<User> users = subscribers.get(product);
    for (User u : users) {
      u.acceptTicker(product, p, direction);
    }
  }

  @Override
  public synchronized void publishCancel(CancelMessage cm) {
    String p = cm.getProduct();
    if (!subscribers.containsKey(p)) { return; }
    for (User u : subscribers.get(p)) {
      if (u.getUserName().equals(cm.getUser())) {
        u.acceptMessage(cm);
      }
    }
  }

  @Override
  public synchronized void publishFill(FillMessage fm) {
    String p = fm.getProduct();
    if (!subscribers.containsKey(p)) { return; }
    for (User u : subscribers.get(p)) {
      if (u.getUserName().equals(fm.getUser())) {
        u.acceptMessage(fm);
      }
    }
  }

  @Override
  public synchronized void publishMarketMessage(MarketMessage mm) {
    for (Set<User> users : subscribers.values()) {
      for (User u : users) {
        u.acceptMarketMessage(mm.getState().toString());
      }
    }
  }
}