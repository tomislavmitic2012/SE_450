package publishers;

import client.User;
import price.Price;
import publishers.exceptions.MessagePublisherException;
import publishers.messages.CancelMessage;
import publishers.messages.FillMessage;
import publishers.messages.MarketDataDTO;
import publishers.messages.MarketMessage;

/**
 * Implements the cancel message, fill message, and market message publishers
 * used by registered users of the Stock Market.
 *
 * @author Tomislav S. Mitic
 */
public class MessagePublisher implements
        MessagePublisherSubject {

  private volatile static MessagePublisher instance;
  private MessagePublisherSubject messagePublisherSubjectImpl;

  public static MessagePublisher getInstance() {
    if (instance == null) {
      synchronized (MessagePublisher.class) {
        if (instance == null) {
          instance = MessagePublisherSubjectFactory
                  .createMessagePublisher();
        }
      }
    }
    return instance;
  }

  protected MessagePublisher(MessagePublisherSubject impl) {
    messagePublisherSubjectImpl = impl;
  }

  @Override
  public synchronized void subscribe(User u, String product) throws MessagePublisherException {
    messagePublisherSubjectImpl.subscribe(u, product);
  }

  @Override
  public synchronized void unSubscribe(User u, String product) throws MessagePublisherException {
    messagePublisherSubjectImpl.unSubscribe(u, product);
  }

  @Override
  public synchronized void publishCurrentMarket(MarketDataDTO m) {}

  @Override
  public synchronized void publishLastSale(String product, Price p, int v) {}

  @Override
  public synchronized void publishTicker(String product, Price p) {}

  @Override
  public synchronized void publishCancel(CancelMessage cm) {
    messagePublisherSubjectImpl.publishCancel(cm);
  }

  @Override
  public synchronized void publishFill(FillMessage fm) {
    messagePublisherSubjectImpl.publishFill(fm);
  }

  @Override
  public synchronized void publishMarketMessage(MarketMessage mm) {
    messagePublisherSubjectImpl.publishMarketMessage(mm);
  }
}