package publishers;

import client.User;
import price.Price;
import publishers.exceptions.MessagePublisherException;
import publishers.messages.CancelMessage;
import publishers.messages.FillMessage;
import publishers.messages.MarketDataDTO;
import publishers.messages.MarketMessage;

/**
 * This publisher notifies the user of the last sale of a stock symbol that user
 * is subscribed to. (Stock Symbol, Price, Volume)
 *
 * @author Tomislav S. Mitic
 */
public class LastSalePublisher implements
        MessagePublisherSubject {

  private volatile static LastSalePublisher instance;
  private MessagePublisherSubject messagePublisherSubjectImpl;

 public static LastSalePublisher getInstance() {
    if (instance == null) {
      synchronized (LastSalePublisher.class) {
        if (instance == null) {
          instance = MessagePublisherSubjectFactory
                  .createLastSalePublisher();
        }
      }
    }
    return instance;
  }

  protected LastSalePublisher(MessagePublisherSubject impl) {
    messagePublisherSubjectImpl = impl;
  }

  @Override
  public synchronized void subscribe(User u, String product) throws MessagePublisherException {
    messagePublisherSubjectImpl.subscribe(u, product);
  }

  @Override
  public synchronized void unSubscribe(User u, String product) throws MessagePublisherException {
    messagePublisherSubjectImpl.unSubscribe(u, product);
  }

  @Override
  public synchronized void publishCurrentMarket(MarketDataDTO m) {}

  @Override
  public synchronized void publishLastSale(String product, Price p, int v) {
    messagePublisherSubjectImpl.publishLastSale(product, p, v);
  }

  @Override
  public synchronized void publishTicker(String product, Price p) {}

  @Override
  public synchronized void publishCancel(CancelMessage cm) {}

  @Override
  public synchronized void publishFill(FillMessage fm) {}

  @Override
  public synchronized void publishMarketMessage(MarketMessage mm) {}
}