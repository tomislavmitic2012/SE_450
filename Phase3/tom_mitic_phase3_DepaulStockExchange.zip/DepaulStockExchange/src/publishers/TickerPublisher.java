package publishers;

import client.User;
import price.Price;
import publishers.exceptions.MessagePublisherException;
import publishers.messages.CancelMessage;
import publishers.messages.FillMessage;
import publishers.messages.MarketDataDTO;
import publishers.messages.MarketMessage;

/**
 * This publisher notifies the user of the last sale of a stock symbol that user
 * is subscribed to. (Stock Symbol, Price)
 *
 * @author Tomislav S. Mitic
 */
public class TickerPublisher implements
        MessagePublisherSubject {

  private volatile static TickerPublisher instance;
  private MessagePublisherSubject messagePublisherSubjectImpl;

 public static TickerPublisher getInstance() {
    if (instance == null) {
      synchronized (TickerPublisher.class) {
        if (instance == null) {
          instance = MessagePublisherSubjectFactory
                  .createTickerPublisher();
        }
      }
    }
    return instance;
  }

  protected TickerPublisher(MessagePublisherSubject impl) {
    messagePublisherSubjectImpl = impl;
  }

  @Override
  public synchronized void subscribe(User u, String product) throws MessagePublisherException {
    messagePublisherSubjectImpl.subscribe(u, product);
  }

  @Override
  public synchronized void unSubscribe(User u, String product) throws MessagePublisherException {
    messagePublisherSubjectImpl.unSubscribe(u, product);
  }

  @Override
  public synchronized void publishCurrentMarket(MarketDataDTO m) {}

  @Override
  public synchronized void publishLastSale(String product, Price p, int v) {}

  @Override
  public synchronized void publishTicker(String product, Price p) {
    messagePublisherSubjectImpl.publishTicker(product, p);
  }

  @Override
  public synchronized void publishCancel(CancelMessage cm) {}

  @Override
  public synchronized void publishFill(FillMessage fm) {}

  @Override
  public synchronized void publishMarketMessage(MarketMessage mm) {}
}