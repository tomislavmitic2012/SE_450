package publishers;

import client.User;
import price.Price;
import publishers.exceptions.MessagePublisherException;
import publishers.messages.CancelMessage;
import publishers.messages.FillMessage;
import publishers.messages.MarketDataDTO;
import publishers.messages.MarketMessage;

/**
 * An interface defining the behaviors that a MessagePublisherSubject should
 * implements.
 *
 * @author Tomislav S. Mitic
 */
public interface MessagePublisherSubject {

  /**
   * Publishers will need a "subscribe" method for users to call so they can
   * subscribe for data. When calling "subscribe", users will provide a "User"
   * reference (a reference to themselves), and the String stock symbol
   * they are interested.
   *
   * @param u
   * @param product
   * @throws MessagePublisherException
   */
  public void subscribe(User u, String product)
          throws MessagePublisherException;

  /**
   * Publishers will need a "unSubscribe" method for users to call so they can
   * un-subscribe for data. When calling "unSubscribe", users will provide
   * a "User" reference (a reference to themselves), and the String stock symbol
   * they are interested un-subscribing from.
   *
   * @param u
   * @param product
   * @throws MessagePublisherException
   */
  public void unSubscribe(User u, String product)
          throws MessagePublisherException;

  /**
   * Notifies all users of of current market conditions for the given stock.
   *
   * @param m
   */
  public void publishCurrentMarket(MarketDataDTO m);

  /**
   * Notifies users of the last sale out for the given stock.
   * (Stock Symbol, Price, Volume)
   *
   * @param product
   * @param p
   * @param v
   */
  public void publishLastSale(String product, Price p, int v);

  /**
   * Notifies users of the last sale out for the given stock.
   * (Stock Symbol, Price)
   *
   * @param product
   * @param p
   */
  public void publishTicker(String product, Price p);

  /**
   * Notifies the user of a canceled order.
   *
   * @param cm
   */
  public void publishCancel(CancelMessage cm);

  /**
   * Notifies the user of a fulfilled order.
   *
   * @param fm
   */
  public void publishFill(FillMessage fm);

  /**
   * Notifies all users of a market message.
   *
   * @param mm
   */
  public void publishMarketMessage(MarketMessage mm);
}