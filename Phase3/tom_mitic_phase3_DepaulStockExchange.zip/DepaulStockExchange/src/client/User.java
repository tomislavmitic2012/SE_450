package client;

import price.Price;
import publishers.messages.CancelMessage;
import publishers.messages.FillMessage;

/**
 * The "User" interface contains the method declarations that any class that
 * wishes to be a "User" of the DSX trading system must implement.
 *
 * @author Tomislav S. Mitic
 */
public interface User {

  /**
   * This will return the String username of this user.
   *
   * @return the user name
   */
  public String getUserName();

  /**
   * This will accept a String stock symbol ("IBM, "GE", etc), a Price object
   * holding the value of the last sale (trade) of that stock, and the quantity
   * (volume) of that last sale. This info is used by "Users" to track stock
   * sales and volumes and is sometimes displayed in a GUI.
   *
   * @param product
   * @param p
   * @param v
   */
  public void acceptLastSale(String product, Price p, int v);

  /**
   * This will accept a FillMessage object which contains information related to
   * an order or quote trade. This is like a receipt sent to the user to
   * document the details when an order or quote-side of theirs trades.
   *
   * @param fm
   */
  public void acceptMessage(FillMessage fm);

  /**
   * This will accept a CancelMessage object which contains information related
   * to an order or quote cancel. This is like a receipt sent to the user to
   * document the details when an order or quote-side of theirs is canceled.
   *
   * @param cm
   */
  public void acceptMessage(CancelMessage cm);

  /**
   * This will accept a String which contains market information related to a
   * Stock Symbol they are interested in.
   *
   * @param message
   */
  public void acceptMarketMessage(String message);

  /**
   * This will accept a stock symbol ("IBM", "GE", etc), a Price object holding
   * the value of the last sale (trade) of that stock, and a "char" indicator of
   * whether the "ticker" price represents an increase or decrease in the
   * Stock's price. This info is used by "users" to track stock price movement,
   * and is sometimes displayed in a GUI.
   *
   * @param product
   * @param p
   * @param direction
   */
  public void acceptTicker(String product, Price p, char direction);

  /**
   * This will accept a String stock symbol ("IBM", "GE", etc.), a Price object
   * holding the current BUY side price for that stock, an int holding the
   * current BUY side volume (quantity), a Price object holding the current SELL
   * side price for that stock, and an int holding the current SELL side volume
   * (quantity). These values as a group tell the user the "current market" for
   * a stock.<br /><br />
   * AMZN:   BUY 220@12.80 and SELL 100@12.85.<br /><br />
   * This info is used by "Users" to update their market display screen so that
   * they are always looking at the most current market data.
   *
   * @param product
   * @param bp
   * @param bv
   * @param sp
   * @param sv
   */
  public void acceptCurrentMarket(String product, Price bp, int bv, Price sp,
          int sv);
}